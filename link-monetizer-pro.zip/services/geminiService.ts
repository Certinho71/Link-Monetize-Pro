
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const suggestTitlesForUrl = async (url: string): Promise<string[]> => {
  if (!API_KEY) {
    return [
        "Título Sugerido 1 (API Key não configurada)",
        "Título Sugerido 2 (API Key não configurada)",
        "Título Sugerido 3 (API Key não configurada)"
    ];
  }
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Baseado apenas na seguinte URL, gere 3 títulos curtos, atrativos e descritivos, adequados para um link encurtado. A URL é: "${url}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            titles: {
              type: Type.ARRAY,
              items: {
                type: Type.STRING,
              },
            },
          },
        },
      },
    });

    const jsonString = response.text.trim();
    const result = JSON.parse(jsonString);
    return result.titles || [];

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return [];
  }
};
