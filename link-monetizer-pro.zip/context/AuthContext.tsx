
import React, { createContext, useContext, ReactNode } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { AppData, Link, User, Transaction, PixKeyType } from '../types';
import { generateShortCode } from '../utils/helpers';

const CLICK_VALUE = 0.005; // $5 CPM

interface AuthContextType {
  user: User | null;
  links: Link[];
  balance: number;
  transactions: Transaction[];
  login: (username: string) => void;
  logout: () => void;
  addLink: (originalUrl: string, title: string) => Link;
  recordClick: (shortCode: string) => void;
  requestWithdrawal: (amount: number, pixKeyType: PixKeyType, pixKey: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const initialData: AppData = {
  user: null,
  links: [],
  balance: 0,
  transactions: [],
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useLocalStorage<AppData>('linkMonetizerData', initialData);

  const login = (username: string) => {
    setData(prevData => ({ ...prevData, user: { username } }));
  };

  const logout = () => {
    setData(initialData);
  };

  const addLink = (originalUrl: string, title: string): Link => {
    const newLink: Link = {
      id: new Date().toISOString(),
      originalUrl,
      shortCode: generateShortCode(),
      title,
      clicks: 0,
      earnings: 0,
      createdAt: new Date().toISOString(),
    };
    setData(prevData => ({ ...prevData, links: [...prevData.links, newLink] }));
    return newLink;
  };

  const recordClick = (shortCode: string) => {
    setData(prevData => {
        const newLinks = prevData.links.map(link => {
            if (link.shortCode === shortCode) {
                return {
                    ...link,
                    clicks: link.clicks + 1,
                    earnings: link.earnings + CLICK_VALUE,
                };
            }
            return link;
        });
        const newBalance = prevData.balance + CLICK_VALUE;
        return { ...prevData, links: newLinks, balance: newBalance };
    });
  };

  const requestWithdrawal = (amount: number, pixKeyType: PixKeyType, pixKey: string) => {
    if (amount > data.balance) {
        alert("Saldo insuficiente.");
        return;
    }
    const newTransaction: Transaction = {
        id: new Date().toISOString(),
        amount,
        pixKeyType,
        pixKey,
        status: 'pending',
        createdAt: new Date().toISOString(),
    };
    setData(prevData => ({
        ...prevData,
        balance: prevData.balance - amount,
        transactions: [newTransaction, ...prevData.transactions],
    }));
  };

  return (
    <AuthContext.Provider value={{ ...data, login, logout, addLink, recordClick, requestWithdrawal }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
