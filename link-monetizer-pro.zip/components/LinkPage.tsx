
import React, { useState, useEffect, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import useLocalStorage from '../hooks/useLocalStorage';
import { AppData } from '../types';

// This is a standalone page, so we read directly from localStorage
// instead of using context to avoid needing the AuthProvider wrapper.
const LinkPage: React.FC = () => {
    const { shortCode } = useParams<{ shortCode: string }>();
    const [data, setData] = useLocalStorage<AppData>('linkMonetizerData', { user: null, links: [], balance: 0, transactions: [] });
    const [countdown, setCountdown] = useState(10);
    const [redirectUrl, setRedirectUrl] = useState<string | null>(null);

    const link = useMemo(() => {
        return data.links.find(l => l.shortCode === shortCode);
    }, [data.links, shortCode]);

    useEffect(() => {
        if (link && !redirectUrl) {
            setRedirectUrl(link.originalUrl);
            
            // Record the click
            const CLICK_VALUE = 0.005; // $5 CPM
            setData(prevData => {
                const newLinks = prevData.links.map(l => {
                    if (l.shortCode === shortCode) {
                        return {
                            ...l,
                            clicks: l.clicks + 1,
                            earnings: l.earnings + CLICK_VALUE,
                        };
                    }
                    return l;
                });
                const newBalance = prevData.balance + CLICK_VALUE;
                return { ...prevData, links: newLinks, balance: newBalance };
            });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [link, shortCode, setData]);
    
    useEffect(() => {
        if (countdown > 0) {
            const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
            return () => clearTimeout(timer);
        }
    }, [countdown]);

    if (!link) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-base-100 text-white">
                <div className="text-center">
                    <h1 className="text-4xl font-bold text-red-500">Link não encontrado</h1>
                    <p className="mt-4">O link que você tentou acessar não existe ou foi removido.</p>
                </div>
            </div>
        );
    }
    
    return (
        <div className="min-h-screen flex flex-col items-center justify-between bg-base-200 p-4">
            <header className="w-full max-w-5xl flex justify-between items-center py-4">
                <h1 className="text-xl font-bold text-white">Link Monetizer Pro</h1>
                {countdown > 0 ? (
                     <div className="bg-base-300 text-white px-4 py-2 rounded-md">
                        Aguarde {countdown}s...
                    </div>
                ) : (
                    <a 
                        href={redirectUrl ?? '#'}
                        className="bg-brand-primary text-white px-6 py-3 rounded-md font-bold hover:bg-cyan-700 transition-all duration-300 transform hover:scale-105"
                    >
                        Pular Anúncio
                    </a>
                )}
            </header>

            <main className="flex-grow flex items-center justify-center w-full">
                <div className="text-center w-full max-w-4xl p-4">
                     <h2 className="text-3xl font-bold mb-4 text-white">{link.title}</h2>
                     <p className="text-gray-400 mb-8">Você será redirecionado em breve. Seu clique ajuda a apoiar este criador!</p>
                    <div className="bg-base-300 rounded-lg shadow-xl aspect-video w-full flex items-center justify-center">
                        <div className="text-center p-8">
                             <h3 className="text-2xl font-bold text-gray-400">Espaço Publicitário</h3>
                             <p className="text-gray-500 mt-2">Este é um anúncio simulado.</p>
                             <img src={`https://picsum.photos/800/450?random=${shortCode}`} alt="Simulated Ad" className="mt-4 rounded-md opacity-50"/>
                        </div>
                    </div>
                </div>
            </main>

            <footer className="w-full text-center py-4 text-gray-500 text-sm">
                Powered by Link Monetizer Pro
            </footer>
        </div>
    );
};

export default LinkPage;
