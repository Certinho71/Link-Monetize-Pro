
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import DollarSignIcon from './icons/DollarSignIcon';

const Header: React.FC = () => {
  const { user, balance, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `px-3 py-2 rounded-md text-sm font-medium transition-colors ${
      isActive ? 'bg-base-300 text-white' : 'text-gray-300 hover:bg-base-200 hover:text-white'
    }`;

  return (
    <header className="bg-base-200 shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-white font-bold text-xl flex items-center">
                <DollarSignIcon className="h-6 w-6 text-brand-primary mr-2"/>
                Link Monetizer
            </div>
            <nav className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                <NavLink to="/dashboard" className={navLinkClass}>
                  Dashboard
                </NavLink>
                <NavLink to="/withdraw" className={navLinkClass}>
                  Saque
                </NavLink>
              </div>
            </nav>
          </div>
          <div className="flex items-center">
            <div className="text-white mr-4 flex items-center bg-base-300 px-3 py-1.5 rounded-md">
                <span className="font-semibold text-green-400">
                    {balance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
            </div>
            <span className="text-gray-300 mr-4">Olá, {user?.username}</span>
            <button
              onClick={handleLogout}
              className="bg-brand-primary text-white px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-700 transition-colors"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
