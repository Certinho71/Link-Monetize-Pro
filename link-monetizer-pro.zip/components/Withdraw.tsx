
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { PixKeyType, Transaction } from '../types';

const Withdraw: React.FC = () => {
    const { balance, transactions, requestWithdrawal } = useAuth();
    const [amount, setAmount] = useState('');
    const [pixKeyType, setPixKeyType] = useState<PixKeyType>(PixKeyType.EMAIL);
    const [pixKey, setPixKey] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const withdrawalAmount = parseFloat(amount);
        if (withdrawalAmount > 0 && pixKey) {
            if (withdrawalAmount > balance) {
                alert("O valor do saque não pode ser maior que o seu saldo.");
                return;
            }
            requestWithdrawal(withdrawalAmount, pixKeyType, pixKey);
            setAmount('');
            setPixKey('');
            alert('Solicitação de saque enviada com sucesso!');
        }
    };

    const getStatusBadge = (status: 'pending' | 'completed') => {
        return status === 'pending'
            ? 'bg-yellow-500 text-yellow-900'
            : 'bg-green-500 text-green-900';
    };

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-white">Solicitar Saque</h1>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-1">
                    <div className="bg-base-200 p-6 rounded-lg shadow-lg text-center">
                        <p className="text-sm text-gray-400">Saldo Disponível</p>
                        <p className="text-4xl font-bold text-green-400 mt-2">
                            {balance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </p>
                    </div>
                </div>

                <div className="md:col-span-2 bg-base-200 p-6 rounded-lg shadow-lg">
                    <h2 className="text-xl font-semibold mb-4 text-white">Detalhes do Saque</h2>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label htmlFor="amount" className="block text-sm font-medium text-gray-300">Valor (BRL)</label>
                            <input
                                type="number"
                                id="amount"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                required
                                step="0.01"
                                min="1"
                                max={balance}
                                placeholder="100.00"
                                className="mt-1 block w-full bg-base-100 border-base-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm p-2"
                            />
                        </div>
                        <div>
                            <label htmlFor="pixKeyType" className="block text-sm font-medium text-gray-300">Tipo de Chave PIX</label>
                            <select
                                id="pixKeyType"
                                value={pixKeyType}
                                onChange={(e) => setPixKeyType(e.target.value as PixKeyType)}
                                className="mt-1 block w-full bg-base-100 border-base-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm p-2"
                            >
                                {Object.values(PixKeyType).map(type => (
                                    <option key={type} value={type}>{type}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="pixKey" className="block text-sm font-medium text-gray-300">Chave PIX</label>
                            <input
                                type="text"
                                id="pixKey"
                                value={pixKey}
                                onChange={(e) => setPixKey(e.target.value)}
                                required
                                placeholder="sua-chave-pix"
                                className="mt-1 block w-full bg-base-100 border-base-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm p-2"
                            />
                        </div>
                        <button
                            type="submit"
                            className="w-full bg-brand-primary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-cyan-700 transition-colors disabled:bg-gray-500"
                            disabled={!amount || !pixKey || parseFloat(amount) > balance}
                        >
                            Solicitar Saque
                        </button>
                    </form>
                </div>
            </div>

            <div className="bg-base-200 p-6 rounded-lg shadow-lg">
                <h2 className="text-xl font-semibold mb-4 text-white">Histórico de Saques</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-base-300">
                        <thead className="bg-base-100">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Data</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Valor</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Chave PIX</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>
                            </tr>
                        </thead>
                        <tbody className="bg-base-200 divide-y divide-base-300">
                            {transactions.map((tx: Transaction) => (
                                <tr key={tx.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{new Date(tx.createdAt).toLocaleString('pt-BR')}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-green-400 font-medium">{tx.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{tx.pixKeyType} - {tx.pixKey}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadge(tx.status)}`}>
                                            {tx.status === 'pending' ? 'Pendente' : 'Completo'}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                            {transactions.length === 0 && (
                                <tr>
                                    <td colSpan={4} className="text-center py-10 text-gray-400">Nenhuma transação encontrada.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Withdraw;
