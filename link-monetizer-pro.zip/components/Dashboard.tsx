
import React, { useState, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { suggestTitlesForUrl } from '../services/geminiService';
import DollarSignIcon from './icons/DollarSignIcon';
import LinkIcon from './icons/LinkIcon';
import TrendingUpIcon from './icons/TrendingUpIcon';
import { Link } from '../types';

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-base-200 p-6 rounded-lg shadow-lg flex items-center space-x-4">
        <div className="bg-base-300 p-3 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-sm text-gray-400">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
        </div>
    </div>
);

const Dashboard: React.FC = () => {
    const { links, addLink } = useAuth();
    const [newUrl, setNewUrl] = useState('');
    const [newTitle, setNewTitle] = useState('');
    const [suggestedTitles, setSuggestedTitles] = useState<string[]>([]);
    const [isSuggesting, setIsSuggesting] = useState(false);
    
    const stats = useMemo(() => {
        const totalClicks = links.reduce((sum, link) => sum + link.clicks, 0);
        const totalEarnings = links.reduce((sum, link) => sum + link.earnings, 0);
        const cpm = totalClicks > 0 ? (totalEarnings / totalClicks) * 1000 : 0;
        return { totalClicks, totalEarnings, cpm };
    }, [links]);

    const handleGetSuggestions = async () => {
        if (!newUrl) return;
        setIsSuggesting(true);
        setSuggestedTitles([]);
        const titles = await suggestTitlesForUrl(newUrl);
        setSuggestedTitles(titles);
        setIsSuggesting(false);
    };

    const handleShorten = (e: React.FormEvent) => {
        e.preventDefault();
        if (newUrl && newTitle) {
            addLink(newUrl, newTitle);
            setNewUrl('');
            setNewTitle('');
            setSuggestedTitles([]);
        }
    };

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        alert('Link copiado!');
    };
    
    const getShortenedUrl = (shortCode: string) => {
      const { protocol, host, pathname } = window.location;
      const path = pathname.substring(0, pathname.lastIndexOf('/'));
      return `${protocol}//${host}${path}/#/l/${shortCode}`;
    }

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title="Ganhos Totais" value={stats.totalEarnings.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} icon={<DollarSignIcon className="h-6 w-6 text-brand-secondary"/>} />
                <StatCard title="Cliques Totais" value={stats.totalClicks.toString()} icon={<TrendingUpIcon className="h-6 w-6 text-brand-primary"/>} />
                <StatCard title="CPM Médio" value={stats.cpm.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} icon={<LinkIcon className="h-6 w-6 text-yellow-500"/>} />
            </div>

            <div className="bg-base-200 p-6 rounded-lg shadow-lg">
                <h2 className="text-xl font-semibold mb-4 text-white">Encurtar Novo Link</h2>
                <form onSubmit={handleShorten} className="space-y-4">
                    <div>
                        <label htmlFor="url" className="block text-sm font-medium text-gray-300">URL Original</label>
                        <input type="url" id="url" value={newUrl} onChange={(e) => setNewUrl(e.target.value)} required placeholder="https://exemplo.com" className="mt-1 block w-full bg-base-100 border-base-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm p-2"/>
                    </div>
                     <div>
                        <label htmlFor="title" className="block text-sm font-medium text-gray-300">Título do Link</label>
                        <input type="text" id="title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} required placeholder="Meu incrível link" className="mt-1 block w-full bg-base-100 border-base-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm p-2"/>
                    </div>
                    <div className="flex items-center space-x-4">
                        <button type="button" onClick={handleGetSuggestions} disabled={isSuggesting || !newUrl} className="bg-brand-secondary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-emerald-600 disabled:bg-gray-500 transition-colors">
                            {isSuggesting ? 'Sugerindo...' : 'Sugerir Título (IA)'}
                        </button>
                        <button type="submit" className="bg-brand-primary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-cyan-700 transition-colors">Encurtar Link</button>
                    </div>
                </form>
                {suggestedTitles.length > 0 && (
                    <div className="mt-4">
                        <h3 className="text-sm font-medium text-gray-300">Sugestões:</h3>
                        <div className="flex flex-wrap gap-2 mt-2">
                            {suggestedTitles.map((title, i) => (
                                <button key={i} onClick={() => setNewTitle(title)} className="bg-base-300 text-sm text-gray-200 px-3 py-1 rounded-full hover:bg-brand-primary transition-colors">
                                    {title}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            <div className="bg-base-200 p-6 rounded-lg shadow-lg">
                <h2 className="text-xl font-semibold mb-4 text-white">Meus Links</h2>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-base-300">
                        <thead className="bg-base-100">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Título / URL</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Link Encurtado</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Cliques</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Ganhos</th>
                            </tr>
                        </thead>
                        <tbody className="bg-base-200 divide-y divide-base-300">
                            {links.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map((link: Link) => (
                                <tr key={link.id}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm font-medium text-white">{link.title}</div>
                                        <div className="text-sm text-gray-400 truncate max-w-xs">{link.originalUrl}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <button onClick={() => copyToClipboard(getShortenedUrl(link.shortCode))} className="text-sm text-brand-primary hover:text-cyan-400 transition-colors">
                                           {getShortenedUrl(link.shortCode)}
                                        </button>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{link.clicks}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-green-400">{link.earnings.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                                </tr>
                            ))}
                             {links.length === 0 && (
                                <tr>
                                    <td colSpan={4} className="text-center py-10 text-gray-400">Nenhum link criado ainda.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
