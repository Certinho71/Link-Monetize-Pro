
export interface Link {
  id: string;
  originalUrl: string;
  shortCode: string;
  title: string;
  clicks: number;
  earnings: number;
  createdAt: string;
}

export interface User {
  username: string;
}

export enum PixKeyType {
  CPF = 'CPF/CNPJ',
  EMAIL = 'E-mail',
  PHONE = 'Celular',
  RANDOM = 'Chave Aleatória',
}

export interface Transaction {
  id: string;
  amount: number;
  pixKeyType: PixKeyType;
  pixKey: string;
  status: 'pending' | 'completed';
  createdAt: string;
}

export interface AppData {
  user: User | null;
  links: Link[];
  balance: number;
  transactions: Transaction[];
}
